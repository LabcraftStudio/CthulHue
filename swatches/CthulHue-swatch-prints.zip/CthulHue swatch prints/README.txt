CthulHue swatch prints - Bambu PLA Palette CMYKW mixes
Designed by Sarah at Labcraft Studio with CthulHue. Released under AGPL-3.0 with the app.

What's here
- Tile sets 1-5: 290 mix tiles (every mix in CthulHue's measured mix gallery), plus 10 pure
  Cyan/Magenta/Yellow/Black/White tiles per set. Each tile is 18 x 18 x 3.2 mm, printed on its
  edge, with its number raised (mirrored) on the back. Print on the H3C with the AMS loaded with
  Bambu PLA Palette Cyan, Magenta, Yellow, Black and White.
- Frame-triangle: one frame per three-filament family, 21 pockets (18 mixes + the 3 pure
  colors at the corners). Print 10. See guide-triangles.png for which tile goes where.
- Frame-pair-strip: one strip per two-filament family, 13 pockets. Print 10, or print the
  single Frame-pair-board instead (all 10 pairs, 130 tiles). See guide-pairs.png.
- Frames print flat in any one color (a P1S is fine). Pocket clearance is 0.03 mm per side;
  tiles pop out when the frame is flipped over.
- swatch-key.csv: tile number, filaments, recipe and preview color for every tile. In
  CthulHue, each mix in the New mix gallery shows its tile number.

Mix colors are Bambu Studio's measured recipes (Bambu Studio, Copyright Bambu Lab, AGPL-3.0).
